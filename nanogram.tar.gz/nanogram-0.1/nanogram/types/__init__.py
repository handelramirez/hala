telegram_type = {
    "array"    : "array",
    "user"     : "User",
    "chat"     : "Chat",
    "dice"     : "Dice",
    "game"     : "Game",
    "poll"     : "Poll",
    "venue"    : "Venue",
    "video"    : "Video",
    "audio"    : "Audio",
    "photo"    : "Photo",
    "voice"    : "Voice",
    "invoice"  : "Invoice",
    "location" : "Location",
    "contact"  : "Contact",
    "sticker"  : "Sticker",
    "document" : "Document",
    "message"  : "Message",
    "videoNote": "VideoNote",
    "animation": "Animation",
    "photoSize": "PhotoSize",
    "chatPhoto": "ChatPhoto",
    "pollOption" : "PollOption",
    "callbackGame" : "CallbackGame",
    "chatLocation"  : "ChatLocation",
    "passportData"  : "PassportData",
    "messageEntity" : "MessageEntity",
    "messageEntity" : "MessageEntity",
    "keyboardButton": "KeyboardButton",
    "chatPermisions": "ChatPermisions",
    "voiceChatEnded": "VoiceChatEnded",
    "voiceChatStarted": "VoiceChatStarted",
    "successfulPayment": "SuccessfulPayment",
    "voiceChatScheduled": "VoiceChatScheduled",
    "inlineKeyboardButton": "InlineKeyboardButton",
    "inlineKeyboardMarkup": "InlineKeyboardMarkup",
    "keyboardButtonPollType": "KeyboardButtonPollType",
    "proximityAlertTriggered": "ProximityAlertTriggered",
    "voiceChatParticipantsInvited": "VoiceChatParticipantsInvited",
    "messageAutoDeleteTimerChanged": "MessageAutoDeleteTimerChanged",
}

basic_file = {
    "file_id": str,
    "file_unique_id": str
}

types = {
    "User": [
        {
            "id": int,
            "is_bot": bool,
            "first_name": str,
        },
        {
            "last_name": str,
            "username": str,
            "language_code": str,
            "can_join_groups": bool,
            "can_read_all_groups_messages": bool,
            "supports_inline_queries": bool
        }
    ],
    "Chat": [
        {
            "id": int,
            "type": str,
        },
        {
            "title": str,
            "username": str,
            "first_name": str,
            "last_name": str,
            "photo": telegram_type["chatPhoto"],
            "bio": str,
            "description": str,
            "invite_link": str,
            "pinned_message": telegram_type["message"],
            "permissions": telegram_type["chatPermisions"],
            "show_mode_delay": int,
            "message_auto_delete_time": int,
            "sticker_set_name": str,
            "can_set_sticker_set": bool,
            "linked_chat_id": int,
            "location": telegram_type["chatLocation"]
        }
    ],
    "Message": [
        {
            "message_id": int,
            "date": int,
            "chat": telegram_type["chat"],
        },
        {
            "from": telegram_type["user"],
            "sender_chat": telegram_type["chat"],
            "forward_from": telegram_type["user"],
            "forward_from_chat": int,
            "forward_signature": str,
            "forward_sender_name": str,
            "forward_date": int,
            "reply_to_message": telegram_type["message"],
            "via_bot": telegram_type["user"],
            "edit_date": int,
            "media_group_id": str,
            "author_signature": str,
            "text": str,
            "entities": [telegram_type["array"], telegram_type["messageEntity"]],
            "animation": telegram_type["animation"],
            "audio": telegram_type["audio"],
            "document": telegram_type["document"],
            "photo": [telegram_type["photo"], telegram_type["photoSize"]],
            "sticker": telegram_type["sticker"],
            "video": telegram_type["video"],
            "video_note": telegram_type["videoNote"],
            "voice": telegram_type["voice"],
            "caption": str,
            "caption_entities": [telegram_type["array"], telegram_type["messageEntity"]],
            "contact": telegram_type["contact"],
            "dice": telegram_type["dice"],
            "game": telegram_type["game"],
            "poll": telegram_type["poll"],
            "venue": telegram_type["venue"],
            "location": telegram_type["location"],
            "new_chat_members": [telegram_type["array"], telegram_type["user"]],
            "left_chat_members": telegram_type["user"],
            "new_chat_title": str,
            "new_chat_photo": [telegram_type["array"], telegram_type["photoSize"]],
            "delete_chat_photo": bool,
            "group_chat_created": bool,
            "supergroup_chat_created": bool,
            "channel_chat_created": bool,
            "message_auto_delete_timer_changed": telegram_type["messageAutoDeleteTimerChanged"],
            "migrate_to_chat_id": int,
            "migrate_from_chat_id": int,
            "pinned_message": telegram_type["message"],
            "invoice": telegram_type["invoice"],
            "successful_payment": telegram_type["successfulPayment"],
            "connected_website": str,
            "passport_data": telegram_type["passportData"],
            "proximity_alert_triggered": telegram_type["proximityAlertTriggered"],
            "voice_chat_scheduled": telegram_type["voiceChatScheduled"],
            "voice_chat_started": telegram_type["voiceChatStarted"],
            "voice_chat_ended": telegram_type["voiceChatEnded"],
            "voice_chat_participants_invited": telegram_type["voiceChatParticipantsInvited"],
            "reply_markup": telegram_type["inlineKeyboardMarkup"]
        }
    ],
    "MessageEntity": [
        {
            "type": str,
            "offset": int,
            "length": int,
        },
        {
            "url": str,
            "user": telegram_type["user"],
            "language": str
        }
    ],
    "PhotoSize": [
        {
            **basic_file,
            "width": int,
            "height": int,
        },
        {
            "file_size": int
        }
    ],
    "Animation": [
        {
            **basic_file,
            "width": int,
            "height": int,
            "duration": int,
        },
        {
            "thumb": telegram_type["photoSize"],
            "file_name": str,
            "mime_type": str,
            "file_size": int
        }
    ],
    "Audio": [
        {
            **basic_file,
            "duration": int
        },
        {
            "performer": str,
            "title": str,
            "file_name": str,
            "mime_type": str,
            "file_size": int,
            "thumb": telegram_type["photoSize"]
        }
    ],
    "Document": [
        {
            **basic_file,
            "thumb": telegram_type["photoSize"],
            "file_name": str,
            "mime_type": str,
            "file_size": int
        }
    ],
    "Video": [
        {
            **basic_file,
            "width": int,
            "height": int,
            "duration": int,
        },
        {
            "thumb": telegram_type["photoSize"],
            "file_name": str,
            "mime_type": str,
            "file_size": int
        }
    ],
    "VideoNote": [
        {
            **basic_file,
            "length": int,
            "duration": int,
        },
        {
            "thumb": telegram_type["photoSize"],
            "file_size": int
        }
    ],
    "Voice": [
        {
            **basic_file,
            "duration": int
        },
        {
            "mime_type": str,
            "file_size": int
        }
    ],
    "Contact": [
        {
            "phone_number": str,
            "first_name": str,
        },
        {
            "last_name": str,
            "user_id": int,
            "vcard": str
        }
    ],
    "Dice": [
        {
            "emoji": str,
            "value": int
        }
    ],
    "PollOption": [
        {
            "text": str,
            "voter_count": int
        }
    ],
    "PollAnswer": [
        {
            "poll_id": str,
            "user": telegram_type["user"],
            "option_ids": [telegram_type["array"], int]
        }
    ],
    "Poll": [
        {
            "id": str,
            "question": str,
            "options": [telegram_type["array"], telegram_type["pollOption"]],
            "total_voter_count": bool,
            "is_closed": bool,
            "is_anonymous": bool,
            "type": str,
            "allows_multiple_answers": bool,
        },
        {
            "correct_option_id": int,
            "explanation": str,
            "explanation_entities": [telegram_type["array"], telegram_type["messageEntity"]],
            "open_period": int,
            "close_date": int
        }
    ],
    "Location": [
        {
            "longitude": float,
            "latitude": float,
        },
        {
            "horizontal_accuracy": float,
            "live_period": int,
            "heading": int,
            "proximity_alert_radius": int
        }
    ],
    "Venue": [
        {
            "location": telegram_type["location"],
            "title": str,
            "address": str,
        },
        {
            "foursquare_id": str,
            "foursquare_type": str,
            "google_place_id": str,
            "google_place_type": str
        }
    ],
    "ProximityAlertTriggered": [
        {
            "traveler": telegram_type["user"],
            "watcher": telegram_type["user"],
            "distance": int
        }
    ],
    "MessageAutoDeleteTimerChanged": [
        {
            "message_auto_delete_time": int
        }
    ],
    "VoiceChatScheduled": [
        {
            "start_date": int
        }
    ],
    "VoiceChatStarted": [
        {}
    ],
    "VoiceChatEnded": [
        {
            "duration": int
        }
    ],
    "VoiceChatParticipantsInvited": [
        {
            "users": [telegram_type["array"], telegram_type["user"]]
        }
    ],
    "UserProfilePhotos": [
        {
            "total_count": int,
            "photos": [telegram_type["array"], [telegram_type["array"], telegram_type["photoSize"]]]
        }
    ],
    "File": [
        basic_file,
        {
            "file_size": int,
            "file_path": str
        }
    ],
    "ReplyKeyboardMarkup": [
        {
            "keyboard": [telegram_type["array"], [telegram_type["array"], telegram_type["keyboardButton"]]]
        },
        {
            "resize_keyboard": bool,
            "one_time_keyboard": bool,
            "input_field_placeholder": bool,
            "selective": bool
        }
    ],
    "KeyboardButton": [
        {
            "text": str
        },
        {
            "request_contact": bool,
            "request_location": bool,
            "request_poll": telegram_type["keyboardButtonPollType"]
        }
    ],
    "KeyboardButtonPollType": [
        {
            "type": str
        }
    ],
    "ReplyKeyboardRemove": [
        {
            "remove_keyboard": [bool, True],
            "selective": bool
        }
    ],
    "InlineKeyboardMarkup": [
        {
            "inline_keyboard": [telegram_type["array"], [telegram_type["array"], telegram_type["inlineKeyboardButton"]]]
        }
    ],
    "InlineKeyboardButton": [
        {
            "text": str
        },
        {
            "url": str,
            "login_url": str,
            "callback_data": str,
            "switch_inline_query": str,
            "switch_inline_query_current_chat": str,
            "callback_game": telegram_type["callbackGame"],
            "pay": bool
        }
    ],
    "LoginUrl": [
        {
            "url": str
        },
        {
            "forward_text": str,
            "bot_username": str,
            "request_write_access": bool
        }
    ],
    "CallbackQuery": [
        {
            "id": str,
            "from": telegram_type["user"],
        },
        {
            "message": telegram_type["message"],
            "inline_message_id": str,
            "chat_instance": str,
            "data": str,
            "game_short_name": str
        }
    ],
    "ForceReply": [
        {
            "force_reply": [bool, True]
        },
        {
            "input_field_placeholder": str,
            "selective": bool
        }
    ],
    "ChatPhoto": [
        {
            "small_file_id": str,
            "small_file_unique_id": str,
            "big_file_id": str,
            "big_file_unique_id": str
        }
    ],
    "ChatInviteLink": [
        {
            "invite_link": str,
            "creator": telegram_type["user"],
            "is_primary": bool,
            "is_revoked": bool,
        },
        {
            "expire_date": int,
            "member_limit": int
        }
    ],
    "ChatMember": {
        "ChatMemberOwner": [
            {
                "status": [str, "creator"],
                "user": telegram_type["user"],
                "is_anonymous": bool,
                "custom_title": str
            }
        ],
        "ChatMemberAdministrator": [
            {
                "status": [str, "administrator"],
                "user": telegram_type["user"],
            },
            {
                "can_be_edited": bool,
                "is_anonymmous": bool,
                "can_manage_chat": bool,
                "can_delete_messages": bool,
                "can_manage_voice_chats": bool,
                "can_restrict_members": bool,
                "can_promote_members": bool,
                "can_change_info": bool,
                "can_invite_users": bool,
                "can_post_messages": bool,
                "can_edit_messages": bool,
                "can_pin_messages": bool,
                "custom_title": str
            }
        ],
        "ChatMemberMember": [
            {
                "status": [str, "member"],
                "user": telegram_type["user"]
            }
        ],
        "ChatMemberRestricted": [
            {
                "status": [str, "restricted"],
                "user": telegram_type["user"]
            }
        ]
    }
}

class DynamicType:
    def __init__(self, d):
        data = None
        self.type = None
        for t in [*types.keys()]:
            exit_ = False
            if type(types[t]) == dict:
                for c in [*types[t].keys()]:
                    for chl in [*types[t][c][0].keys()]:
                        try:
                            d[chl]
                        except:
                           exit_ = True
                           break
                    if exit_:    data = None;break
                    else:   data = d;self.type
                if data:
                    break
                else:
                    continue
            else:
                for chl in types[t][0]:
                    try:
                        d[chl]
                    except:
                        exit_ = True
                        break

                if exit_:    data = None;continue
                else:   data = d;self.type = t
                break

        if data == None:
            raise Exception("Type not founded")

        self.__name__ = self.type
        self.data = data

    def __repr__(self):
        return f"<{self.type} {self.data}>"

    def __getattr__(self, arg):
        return self.data[arg]
