from .raw import callapi, verifyToken
from functools import partial

class Bot:
    methods = {
        "getMe": (None),
        "logOut": (None),
        "close": (None),
        "sendMessage": (["chat_id", "text"], ["parse_mode", "entries", "disable_web_page_preview", "disable_notification", "reply_to_message_id", "reply_markup"]),
        "forwardMessage": (["chat_id", "from_chat_id", "message_id"], ["disable_notification"]),
        "copyMessage": (["chat_id", "from_chat_id", "message_id"], ["caption", "parse_mode", "caption_entities", "disable_notification", "reply_to_message_id", "allow_sending_without_reply", "reply_markup"]),
        "sendPhoto": ([])
    }

    def __init__(self, bottoken, verify_requests = True, verifyToken = True):
        # If you don't verify your token, the class creation it's more faster,
        # but if you wanna get the bot info, you need to do a request to
        # telegram servers, but, you can set self.me easy, but the best way
        # it's using verifyToken.
        #
        # This feature its used for bot's instances what's need to be created
        # by the fastest way.

        if verifyToken:
            self.me = verifyToken(bottoken)["result"]

        self.bottoken = bottoken

        # This is for avoiding the request verification, this maybe useful if
        # the telegram api change's and you don't wanna get an error.
        self.verify_requests = verify_requests

    def parse(self, path, *args, **kwargs):
        # Checks if the function was requested does not have support in this
        # package yet, and avoid's the verification.
        if path not in [*Bot.methods] or self.verify_requests == False:
            data = callapi(bottoken = self.bottoken, path = path, **kwargs)

        else:
            _args_ = {}
            method  = path.strip("/")
            required = [*Bot.methods[method][0]]
            funcargs = [*Bot.methods[method][1]]
            all      = [*required, *funcargs]

            # Check's if the required values are more than the sended
            if len(required) + 1 <= len(args):
                raise IndexError(
                    f"The \"%s\" api method take's %d arguments but %d was reicived" % (path, len(required), len(args))
                )

            else:
                for i in range(0, len(args)):
                    _args_.update({all[i]: args[i]})

            for i in [*kwargs.keys()]:
                if i in all:
                    _args_.update({i: kwargs[i]})
                else:
                    raise IndexError(
                        "The \"%s\" api method doesn't need the parameter %s" % (path.strip("/"), i)
                    )

            # Check's again if the required len its more than the args len
            if len(_args_) + 1 <= len(required):
                raise IndexError(
                    f"The \"%s\" api method requires {required} arguments, but only those {[*_args_.keys()]} are reicived" % (path)
                )

            # Send's the request to the api
            data = callapi(path = path, bottoken = self.bottoken, **_args_)

        # Check's if everything its okay in the response
        if data["ok"] == False:
            raise raw.BadRequest(data["description"].split(":")[1].strip(" ").capitalize())

        else:
            # Return's the result of the request
            return data["result"]

    def __getattr__(self, *args):
        if args[0] == "me":
            raise Exception(
                "You don't have verified your token, so you need to do %s.getMe()" % type(self).__name__
            )

        return partial(self.parse, path = args[0])

    def verifyAttr(self, attr):
        pass

class PollingUpdater:
    def __init__(self, bot_instance):
        self.bot = bot_instance

    def getUpdates(self, timeout = 60, **kwargs):
        return callapi(path = "getUpdates", bottoken = self.bot.bottoken, timeout = timeout, **kwargs)

