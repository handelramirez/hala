import requests

class Response(dict):
    def __getattr__(self, *args):
        if args[0] not in [*self.keys()]:
            raise IndexError(
                "Class \"%s\" not have's \"%s\" key" % (type(self).__name__, args[0])
            )

        return self[args[0]]

class BadRequest(Exception):
    """
        Raised when you do an invalid request
        to telegram servers.
    """
    pass

telegram_api_url = "api.telegram.org/bot"
def callapi(path, bottoken, **kwargs):
    req_url = f"https://{telegram_api_url}{bottoken}/{path.rstrip('/')}"
    return requests.get(
        req_url,
        params = kwargs
    ).json()

def verifyToken(token):
    data = callapi("getMe", token)
    if data["ok"] == False:
        raise BadRequest("Invalid token")

    return data

