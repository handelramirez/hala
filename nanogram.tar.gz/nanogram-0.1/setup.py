import setuptools

setuptools.setup(
    name = "nanogram",
    author = "x93",
    license = "GPL v3",
    version = "0.1",
    description = """
    A python3 lib for make requests to the telegram api.

    Changelog:

    0.1 - Pre release
    """,
    packages = ["nanogram", "nanogram.api", "nanogram.types"]
)
